ALTER TABLE "users" ADD COLUMN "phone" text;
